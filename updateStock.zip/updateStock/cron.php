<?php
/**
 *
 * @author    Cis Modules
 * @copyright 2016-2018 Cis Modules
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */
ini_set('memory_limit', '-1');
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../init.php');

/**For dynamic cron, check the token
For testing I a commenting the code**/

// $token = Tools::getValue("token");
// if(Configuration::get('UPDATESTOCK_CRON_TOKEN') != $token){
//     echo 'Token mismatch'; die;
// }

/***As we don't have API for Invertory management so we assume that it return data in this json file***/
$jsonData = file_get_contents("sample.json");

$invertoryData = json_decode($jsonData);

foreach ($invertoryData as $inventory) {
        $id_product = $inventory->id;
        $id_attribute = $inventory->id_attribute;
        $quantity = $inventory->stock;

        /**check if product exists**/
        $product = new Product($id_product);
        if($product)
        {
            StockAvailable::setQuantity($id_product, $id_attribute, $quantity);
        }else{
            echo 'Product id does not match';
        }
}
echo "Cron updated Successfully";