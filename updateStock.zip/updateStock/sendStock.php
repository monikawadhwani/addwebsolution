<?php
/**
 *
 * @author    Cis Modules
 * @copyright 2016-2018 Cis Modules
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */
ini_set('memory_limit', '-1');
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../init.php');


/**Read Post Data**/
$request = file_get_contents("php://input");


if(!empty($request)){
	$inputData = json_decode($request);

	$result = array('sucess'=> true,
			'data' => $inputData);
}else{
	$result = array('sucess'=> false,
			'data' => 'No Result');
}

echo json_encode($result);