<?php
/**
* 2007-2020 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2020 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class UpdateStock extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'updateStock';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Monika';
        $this->need_instance = 1;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Update Stock');
        $this->description = $this->l('Update stock in inventory');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall this module?');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

   
    public function install()
    {
        $token = md5(uniqid(rand(), true));
        Configuration::updateValue('UPDATESTOCK_CRON_TOKEN', $token);

         /**
         * set the cron url
         */
        $shopurl = new ShopUrl($this->context->shop->id);
        $cronurl     = $shopurl->getURL().'modules/'.$this->name.'/cron.php?token='.$token;

        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('backOfficeHeader') &&
            $this->registerHook('actionValidateOrder') &&
            $this->installCronjobeditor($cronurl);
    }

    /**
    * Function to add cronjob in to cronjob editor module 
    */
    public function installCronjobeditor($task)
    {        
        if (Module::isInstalled('cronjobs')) {            
            $is_frequency_valid = true;
            $id_shop = (int)Context::getContext()->shop->id;
            $id_shop_group = (int)Context::getContext()->shop->id_shop_group;
            $hour  = 0;
            $day   = -1;
            $month = -1;
            $day_of_week = -1;
            $description = $this->l('Update Stock auto synchronization');            

            $query = 'INSERT INTO '._DB_PREFIX_.'cronjobs
            (`description`, `task`, `hour`, `day`, `month`, `day_of_week`, `updated_at`, `one_shot`, `active`, `id_shop`, `id_shop_group`)
            VALUES (\''.  Db::getInstance()->escape($description) .'\', \'' .
            urlencode($task)  . '\', \''.$hour.'\', \''.$day.'\', \''.$month.'\', \''.$day_of_week.'\',
            NULL, TRUE, TRUE, '.$id_shop.', '.$id_shop_group.')';
            Db::getInstance()->execute($query);                
            return true;
        }
    }

    public function uninstall()
    {
        $this->uninstallCronjobeditor();

        Configuration::deleteByName('UPDATESTOCK_CRON_TOKEN');

        return parent::uninstall();
    }

     /*
    * Function to delete cronjob in cronjob editor module
    */
    public function uninstallCronjobeditor()
    {
        if (Module::isInstalled('cronjobs')) {
            $shopurl = new ShopUrl($this->context->shop->id);
            $url   = $shopurl->getURL();
            $token = Configuration::get('UPDATESTOCK_CRON_TOKEN');
            $task  = $url.'modules/'.$this->name.'/cron.php?token='.$token;
            $id_shop = (int)Context::getContext()->shop->id;
            $id_shop_group = (int)Context::getContext()->shop->id_shop_group;
            $query = 'SELECT `active` FROM '._DB_PREFIX_.'cronjobs
                WHERE `task` = \''.urlencode($task).'\' AND `updated_at` IS NULL
                AND `one_shot` IS TRUE
                AND `id_shop` = \''.$id_shop.'\' AND `id_shop_group` = \''.$id_shop_group.'\'';
            if ((bool)Db::getInstance()->getValue($query) == true) {
                $deletequery = 'DELETE FROM '._DB_PREFIX_.'cronjobs WHERE `task` = \''.urlencode($task).'\'';
                Db::getInstance()->execute($deletequery);
            }
        }
    }

 

    /**
    * Add the CSS & JavaScript files you want to be loaded in the BO.
    */
    public function hookBackOfficeHeader()
    {
        if (Tools::getValue('module_name') == $this->name) {
            $this->context->controller->addJS($this->_path.'views/js/back.js');
            $this->context->controller->addCSS($this->_path.'views/css/back.css');
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
    }

    /**Function will call when Order will place***/
    public function hookActionValidateOrder($params)
    {
        $order = $params['order'];
        $order_id = (int)$order->id;        
        
        $products = $params['cart']->getProducts(true);        

        $sendData = array();
        foreach ($products as $product) {                        
            $sendData[] = array('item_id' => $product['id_product'],
                                'qty' => $product['cart_quantity']
                                 );
        }
               
        /**We will check the Inventory stock using its API functions and update stock in Inventory,
        as we don't have API we are calling webhooks***/

        

        $data = json_encode($sendData);

        $shopurl = new ShopUrl($this->context->shop->id);
        $url = $shopurl->getURL().'modules/'.$this->name.'/sendStock.php';

        $handle = curl_init($url);        
        curl_setopt($handle, CURLOPT_POST, true);
        curl_setopt($handle, CURLOPT_POSTFIELDS, $data);
        curl_setopt($handle, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        $result = curl_exec($handle);

        print_r($result); die;

        curl_close($handle);        
    }
}
